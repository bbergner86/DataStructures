//Standard includes for programming
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Char array for ones
char *ones[10]={ "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};

//Char array for teens
char *teens[10]={ "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
"nineteen"};

//Char array for tens
char *tens[8]={ "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};

//Function to print Zero thru Nine
void PrintOneDigit(int d)
{
	if (d>=0 && d<=9)
	printf("%s ", ones[d]);
}

//Function to print Ten thru Nineteen
void PrintTeen(int d)
{
        if (d>=10 && d<=19)  
        printf("%s ", teens[d%10]);
}

//Function to print 20 thru 99
void PrintDouble(int d)
{
        if (d>=20 && d<=99){
        printf("%s ", tens[d/10-2]);
	PrintOneDigit(d % 10);
	}
}

//Function to print 100 thru 999
void PrintHundred(int d)
{
        if (d>=100 && d<=999){
        printf("%s hundred ", ones[d/100]);
	if((d%100)>=20 && (d%100)<=99)
	PrintDouble(d%100);
	if((d%100)>=10 && (d%100)<=19)
	PrintTeen(d%100);
	if(1 < d%100 < 10)
	PrintOneDigit(d%100);
	}
}

//Function to print 1000 thru 999999
void PrintThousand(int d)
{
        if (d>=1000 && d<=9999){
        printf("%s thousand ", ones[d/1000]);
	if(1 < d%1000 < 10)
        PrintOneDigit(d%1000);
        if(10 <= d%1000 < 20)
        PrintTeen(d%1000);
        if(20 <= d%1000 < 100)
        PrintDouble(d%1000);
        if(100 <= d%1000 < 1000)
	PrintHundred(d%1000);
	}
	if(d>=10000 && d<=99999){
	if(d>=20000 && d<=99999){
        PrintDouble(d/1000);
	}
        if(d>=10000 && d<=19999){
        PrintTeen(d/1000);
	}
	printf("thousand ");
 	if(1 < d%1000 < 10)
	PrintOneDigit(d%1000);
	if(10 <= d%1000 < 20)
	PrintTeen(d%1000);
	if(20 <= d%1000 < 100)
	PrintDouble(d%1000);
	if(100 <= d%1000 < 1000)
	PrintHundred(d%1000);	
}
	if(d>=100000 && d<=999999) {
	printf("%s hundred ", ones[d/100000]);
	PrintThousand(d%100000);
	}
}

int main() {
	int num = 1;
	while(num >= 0) {
	printf("\nNumber: ");
	scanf("%d", &num);
	if(num >= 1000 && num < 1000000) {
	PrintThousand(num);
}
	if(num >= 100 && num <= 999) {
	PrintHundred(num);
}
	if(num >= 20 && num <=99) {
	PrintDouble(num);
}
	if(num >= 10 && num <=19) {
	PrintTeen(num);
}
	if(num >= 0 && num <=9) {
	PrintOneDigit(num);
}
	else if(num >= 1000000 || num <= -1) { 
	printf("Number invalid. \n");
	break;
}
}
	return(0);
}
