#include <stdio.h>
#include <stdlib.h>
#include "random.h"

//Declaration prototypes
int findDigit(int s, int *arr);
int checkDifference(int *a);
void answer(int * s);

/****************************************************/


int findDigit(int s, int *arr) {
    int i = 0;
    for (i = 0; i < 4; i++) {
    arr[i] = s%10;
    s = s/10;
    }
	return (*arr);
}


int checkDifference(int *a) {
 int i; 
 int j = 0; 
     for(i = 0; i < 4; i++) {
        for(j = i + 1; j < 4; j++) {
	   if(a[i] == a[j]) {
	     return 1;
	}
       }
      }
 	return 0;
}


main(){
 
 int secret;
 int secretArr[4] = {0};

 Randomize();
 do{
 secret = RandomInteger(1000, 9999);
 printf("%d\n", secret); //delete later
 findDigit(secret, secretArr);
 } while(checkDifference(secretArr)==1);

 answer(secretArr);

}


void answer(int * s) {

 int ansArr[4] = {0};
 int i = 0;
 int j = 0;
 int k = 0; 
 int ans = 0;
 int in_place = 0;
 int not_exist = 0;
 int out_of_place = 0;
 int attempt = 0;
  
  do {
 do {
 printf("Guess the secret number: ");
 scanf("%d", &ans);
 findDigit(ans, ansArr);
 k = checkDifference(ansArr);
 
 if(k == 1) {
	attempt++;
	printf("An attempt was used. Guess a new number composed of 4 different digits between 1000-9999.\n");
 } 
} while(k == 1 || ans <= 1000 || ans >= 9999);


 for(i = 0; i < 4; i++) {
        for(j = 0; j < 4; j++) {
        if(s[i] == ansArr[j]) {
	if(i == j) {
                in_place++;
        } else if(i != j) {
                out_of_place++;
        }
       }
      }	
     }

  if(in_place == 4) {	
	printf("Congratulations! You guessed the secret number.\n");
	exit(0);
	}

        not_exist = 4 - (in_place + out_of_place);
        printf("%d digit(s) are in place\n", in_place);
	printf("%d digit(s) are out of place\n", out_of_place);
	printf("%d digit(s) does not exist\n", not_exist);

 attempt++;
 in_place = 0;
 out_of_place;

} while(attempt != 40);
}

