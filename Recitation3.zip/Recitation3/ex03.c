#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//function protoypes
void set_array_rand(int x[], int n);
void SELECTION_SORT(int x[], int n);
void MERGE(int a[], int na, int b[], int nb, int c[], int nc);
void PRINT_ARRAY(char *name, int x[], int nx);

main() {

/* 1. Declare three integer arrays as follows */
int a[50], b[70], c[120];

/* 2. implement a function set_array_rand(int x[], int n)
and call it to generate the values in array a and b
randomly. */
set_array_rand(a, 50);
set_array_rand(b, 70);

/* 3. using the SELECTION_SORT(double x[], int n) function,
sort the elements in a and b arrays. */
SELECTION_SORT(a, 50);
SELECTION_SORT(b, 70);

/* 4. implement a MERGE function and call it as follows to
merge the values in arrays a and b into array c such that
the values in c will be sorted after merging */
MERGE(a, 50, b, 70, c, 120);

/* 5. print the values in array c */
PRINT_ARRAY("Array c", c, 120);
}

void set_array_rand(int x[], int n) {

/* 1. randomly generate elements of x array, e.g, */
int i;
for(i = 0; i < n; i++)
x[i] = rand_int(30, 100);
}

int rand_int(int a,int b) {
 return rand()%(b-a+1) + a;
}


/* YOUR CODE */
void SELECTION_SORT(int x[], int n) {
 
 int k,j,m;
 double temp;

	for(k = 0; k < n; k++) {
	m = k;
	for(j = k + 1; j < n; j++) {
	if(x[j] < x[m])
	m = j;
	}	
	temp = x[k];
	x[k] = x[m];
	x[m] = temp;
}
}

void MERGE(int a[], int na, int b[], int nb, int c[], int nc) {

/* merge the values in a and b into c while keeping the values
 sorted. For example, suppose we have the following two
 Arrays a = { 3, 7, 9, 12} and b = {4, 5, 10}
 When we merge these two arrays, we will get
 c = {3, 4, 5, 7, 9, 10, 12}
*/
int i;
int j = 0;
int k = 0;

 	for(i = 0; i < nc; i++) {
	if(a[j] == a[na]) {
        c[i] = b[k];
        k++; 
	} else if(b[k] == b[nb]) {
        c[i] = a[j];
        j++; 
	} else if(a[j] < b[k]) { 
        c[i] = a[j];
	j++; 
	} else if(a[j] > b[k]) {
        c[i] = b[k];
	k++; 
	} else if(a[j] == b[k]) {
	c[i] = a[j];
	c[i + 1] = b[k];
	i++;
	j++;
	k++; }
}
}

void PRINT_ARRAY(char *name, int x[], int nx) {
 /* YOUR CODE */
	int i;
	printf("%s ", name);
	for(i = 0; i < nx; i++) {
	printf("%d ", x[i]);
	}
	printf("\n");

}
