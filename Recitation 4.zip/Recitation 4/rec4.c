#include <stdio.h>
#include <stdlib.h>
#include <string.h>


//execution starts here
int main(int argc, char* argv[]) {

//FILE pointers 
FILE *infp, *outfp;

//checks if correct command arguments
if((strcmp(argv[argc-2], "-input") == 0 && strcmp(argv[argc-4], "-output") == 0)
	|| (strcmp(argv[argc-2], "-output") == 0 && strcmp(argv[argc-4], "-input") == 0)) {

//checks for input/output file names
int i, in, out;
for(i = 0; i < argc; i++) {
if(strcmp(argv[i], "-input") == 0) 
	in = i + 1;
if(strcmp(argv[i], "-output") == 0)
	out = i + 1;
} 

//opens input/output files
infp = fopen(argv[in], "r");
if(infp == NULL)
	exit(0);

outfp = fopen(argv[out], "w");
if(outfp == NULL)
	exit(0);

//scans info from input file and prints info to output file
int event, task, day, numtask, maxday;
int temp = 0, count = 0;
fprintf(outfp, "Projection completion timetable\n");
fprintf(outfp, "---------------------------------------\n");
fprintf(outfp, "Event\tNum of tasks\tMax num of days\n");
fprintf(outfp, "-----\t------------\t---------------\n");
while(!feof(infp)) {
fscanf(infp, "%d %d %d", &event, &task, &day);
if(temp != event) {
	if(temp != 0) {
	fprintf(outfp, "%d\t %d\t\t %d\t \n", temp, numtask, maxday);
	count += maxday;
	}
	temp = event;
	numtask = 1;
	maxday = day;
}else if(temp == event) {
	if(maxday < day)
        maxday = day;
	numtask++;

}
}

//prints out last line of timetable and total number of days
count += maxday;
fprintf(outfp, "%d\t %d\t\t %d\t \n", temp, numtask, maxday);
fprintf(outfp, "---------------------------------------\n");
fprintf(outfp, "Total number of days to finish the project: %d days.", count);

} else { 
//error if input/output is wrong
printf("Error. Output or Input in wrong place.");
exit(0);
}

//closes input/output files
fclose(infp);
fclose(outfp);

//returns 0 for main
return 0;
}
