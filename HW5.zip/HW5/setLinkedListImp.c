#include <stdio.h>
#include <stdlib.h>
#include "genlib.h"
#include "set.h"

#define MAX_ELEMENTS 100

typedef struct cellT {
  setElementT value;
  struct cellT *next;
}cellT;

struct setCDT {
  int count;
  cellT *start;
  cellT *cursor;
};

setADT setNew(){
   setADT set;

   set = New(setADT);
   set->start = set->cursor = New(cellT *);
   set->start->next = NULL;
   set->count = 0;
   return set;
} /* create a new empty set */

void setFree(setADT S){
  cellT *cp, *next;
  
  cp = S->start;
  while(cp) {
    next = cp->next;
    FreeBlock(cp);
    cp = next;
  }
  FreeBlock(S);
} /* free the space allocated for the set S */

int setInsertElementSorted(setADT S, setElementT E){ 
  cellT *tmp, *cp;
   tmp = New(cellT *);
   tmp->value = E;
   tmp->next = NULL;
   cp = S->start;
  if(S->start == NULL || S->start->value > tmp->value) {
    tmp->next = S->start->next;
    S->start->next = tmp;
   } else {
   cp = S->start->next;
   while(cp->next && cp->next->value < tmp->value) {
    cp = cp->next;
  }
  tmp->next = cp->next;
  cp->next = tmp;
 }
  S->count++;
  return S->count;
}
/* if not successful, return 0; otherwise, return the num of elements after the insertion.
Also note that the elements might be given in different orders, but your function should always
keep the set in a sorted manner after each insertion */

setADT setUnion(setADT A, setADT B) {

}
/* returns a new set containing A ∪ B */

setADT setIntersection(setADT A, setADT B) {

}
/* returns a new set containing A ∩ B */

setADT setDifference(setADT A, setADT B){

}
/* returns a new set containing A \ B */

int setCardinality(setADT S){
  return S->count;
} /* return the number of elements in S */

void setPrint(setADT S, char *name){
  printf("%s = {", name);
  cellT *cp;

  for(cp = S->start->next; cp != NULL; cp = cp->next) {
    printf("%d ", cp->value);
  }
  printf("}");
  printf("\n");
  for(cp = S->start; cp != S->cursor; cp = cp->next) {
     printf(" ");
  }
    printf("^\n");
}
